# Frame-Eggs — Farcaster miniapp frame

This is a minimal Vite + React static frame you can deploy and then add to Farcaster as a frame.

Features:
- English UI: "Is the $EGGS token bullish or bearish?"
- Buttons: Bullish / Bearish
- Logo and vote counters
- Client-side persistence via localStorage (demo). For shared/public votes you'll need a backend or contract.

Default embedded Farcaster miniapp used: https://farcaster.xyz/miniapps/Qqjy9efZ-1Qu/eggs

## How to run locally

1. Install dependencies:
```bash
npm install
```

2. Run dev server:
```bash
npm run dev
```

3. Build for production:
```bash
npm run build
npm run preview
```

## Deploy

You can deploy to Vercel, Netlify or GitHub Pages. Just push this folder to a GitHub repo and connect to Vercel or Netlify.

## Notes about wallets & iframes

- The frame includes a toggle to show the Farcaster miniapp iframe. Some sites block embedding; if the iframe appears blank, open the Farcaster URL in a new tab.
- Votes are stored locally in browser storage. To make them shared across users, you need a backend (I can add one if you want).

