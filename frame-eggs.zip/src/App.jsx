import React, {useEffect, useState} from 'react';

/*
Eggs Frame
- Shows a title and question: Is the $EGGS token bullish or bearish?
- Two big buttons: Bullish / Bearish
- Logo (simple SVG) and vote counts
- Persists votes client-side using localStorage (key: 'eggs_votes')
- Optional: query param ?frameUrl=... to display embedded farcaster link in iframe toggle
*/

const STORAGE_KEY = 'eggs_votes_v1';

function loadVotes(){
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {bullish: 0, bearish: 0, votes: {}};
    return JSON.parse(raw);
  } catch(e){
    return {bullish:0,bearish:0,votes:{}};
  }
}

function saveVotes(state){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function Logo({size=64}){
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" aria-hidden>
      <defs>
        <linearGradient id="g" x1="0" x2="1">
          <stop offset="0" stopColor="#FFD36E"/>
          <stop offset="1" stopColor="#FF8A00"/>
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="46" fill="url(#g)" stroke="#222" strokeWidth="2"/>
      <g transform="translate(18,22)" fill="#222">
        <text x="0" y="40" fontFamily="Helvetica, Arial" fontWeight="700" fontSize="36">EGG</text>
      </g>
    </svg>
  );
}

export default function App(){
  const [counts, setCounts] = useState(()=> loadVotes());
  const [votedId, setVotedId] = useState(null);
  const [showIframe, setShowIframe] = useState(false);

  useEffect(()=>{
    // keep local copy in case multiple tabs
    function onStorage(e){
      if (e.key === STORAGE_KEY) {
        setCounts(loadVotes());
      }
    }
    window.addEventListener('storage', onStorage);
    return ()=> window.removeEventListener('storage', onStorage);
  },[]);

  function castVote(choice){
    // simple anti-spam by generating a random client id and storing voted id per session
    const clientId = localStorage.getItem('eggs_client_id') || (() => {
      const id = 'c_' + Math.random().toString(36).slice(2,10);
      localStorage.setItem('eggs_client_id', id);
      return id;
    })();

    // prevent double voting from same client in this demo (stored in votes map)
    const current = loadVotes();
    if (current.votes && current.votes[clientId]) {
      // allow change of vote: subtract previous then add new
      const prev = current.votes[clientId];
      if (prev === choice) return; // no-op
      if (prev === 'bullish') current.bullish = Math.max(0, current.bullish - 1);
      if (prev === 'bearish') current.bearish = Math.max(0, current.bearish - 1);
    }
    if (choice === 'bullish') current.bullish = (current.bullish || 0) + 1;
    if (choice === 'bearish') current.bearish = (current.bearish || 0) + 1;
    current.votes = current.votes || {};
    current.votes[clientId] = choice;
    saveVotes(current);
    setCounts(current);
    setVotedId(clientId);
  }

  const total = (counts.bullish || 0) + (counts.bearish || 0);
  const pct = (n) => total ? Math.round((n/total)*100) : 0;

  // frameUrl default requested by you:
  const defaultFrameUrl = 'https://farcaster.xyz/miniapps/Qqjy9efZ-1Qu/eggs';
  const params = new URLSearchParams(window.location.search);
  const frameUrl = params.get('frameUrl') || defaultFrameUrl;

  return (
    <div className="container">
      <header className="topbar">
        <div className="brand">
          <Logo size={56} />
          <div>
            <h1>$EGGS — Bullish or Bearish?</h1>
            <div className="subtitle">Is the $EGGS token bullish or bearish?</div>
          </div>
        </div>
        <div className="votes-summary">
          <div className="count">{total}</div>
          <div className="label">Total votes</div>
        </div>
      </header>

      <main>
        <div className="question">
          <p>Do you think the <strong>$EGGS</strong> token is <em>bullish</em> or <em>bearish</em>?</p>
        </div>

        <div className="buttons">
          <button className="btn bullish" onClick={()=>castVote('bullish')}>
            🔺 Bullish
            <span className="small"> {counts.bullish || 0} ({pct(counts.bullish)}%)</span>
          </button>

          <button className="btn bearish" onClick={()=>castVote('bearish')}>
            🔻 Bearish
            <span className="small"> {counts.bearish || 0} ({pct(counts.bearish)}%)</span>
          </button>
        </div>

        <div className="explain">
          <small>This is a lightweight client-side poll. Votes are stored locally in your browser (<code>localStorage</code>). To make votes public/shared you need a backend or smart contract — I can add that if you want.</small>
        </div>

        <div className="iframe-toggle">
          <button onClick={()=>setShowIframe(s=>!s)} className="linkish">
            {showIframe ? 'Hide' : 'Show'} embedded Farcaster miniapp
          </button>
        </div>

        {showIframe && (
          <div className="iframe-wrap" role="region" aria-label="farcaster embed">
            <iframe src={frameUrl} title="Farcaster miniapp" sandbox="allow-scripts allow-same-origin allow-forms" />
          </div>
        )}
      </main>

      <footer>
        <div>Made for Farcaster — frame for: <a href={frameUrl} target="_blank" rel="noreferrer">{frameUrl}</a></div>
      </footer>
    </div>
  );
}
